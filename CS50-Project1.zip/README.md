# C

This is the Template Repl for C.

C is a low-level and cross-platform imperative language. It was created in 1972 and many other languages have been influenced by it.

[While there isn't "official" C documentation, check out Microsoft's resources here](https://docs.microsoft.com/en-us/cpp/c-language).